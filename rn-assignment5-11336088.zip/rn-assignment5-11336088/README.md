# Mobile Application Development Assignment 5

This is a mobile application developed for the DCIT202 Mobile Application Development course. The app includes features such as navigation between screens, theme switching, and custom styling to match a provided UI design.

## Features
- Navigation between Home and Settings screens.
- Dark mode and light mode theme switching.
- Custom components and styling to closely match the provided UI mockup.


## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes.

### Prerequisites

Make sure you have the following installed:

- [Node.js](https://nodejs.org/)
- [React Native CLI](https://reactnative.dev/docs/environment-setup)